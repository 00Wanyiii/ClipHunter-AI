# Scripts

No custom runtime code is required for the first no-code MVP.

Add scripts here only when a specific gap cannot be handled reliably in Make/Airtable/provider tooling. Every script should include:
- a clear purpose;
- input/output contract;
- dependency list;
- safe secret handling;
- unit tests or fixtures;
- error handling;
- a documented owner and maintenance note.
