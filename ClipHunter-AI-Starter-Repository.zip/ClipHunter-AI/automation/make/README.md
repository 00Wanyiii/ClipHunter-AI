# Make.com Automation Blueprint

The folder `scenarios/` contains scenario specifications. These are implementation instructions, **not importable Make blueprint JSON exports**. Build and test the scenarios in Make's visual editor, then export actual blueprints from your Make account and store them here.

## Recommended scenarios

### CH-01 — Authorized Asset Intake
**Trigger:** Airtable watch-records or a controlled webhook.

Modules (conceptual):
1. Trigger on new Source Asset.
2. Airtable: fetch linked Streamer.
3. Filter: Permission Status = ACTIVE.
4. Filter: Permission Checked = true and permitted operations include processing.
5. Deduplication: check Asset ID / provider job ID.
6. Update asset status to VALIDATED or BLOCKED.
7. Create audit log.
8. Notify operator if blocked.

### CH-02 — Candidate Clip Processing
**Trigger:** validated source asset.

1. Retrieve asset metadata and authorized media location.
2. Submit media through a supported provider integration/API, if available.
3. Store provider job ID.
4. Poll or receive completion webhook using supported provider capability.
5. Save output to restricted Drive folder.
6. Create Clips records with timestamps, title, caption, score.
7. Set status to PENDING_REVIEW.
8. Create audit log and notify reviewer.

If the clipping provider has no suitable supported API, keep this step manual. Do not invent endpoints or use unauthorized extraction.

### CH-03 — Review Notification
**Trigger:** new Clips record with status PENDING_REVIEW.

1. Build a review message containing clip ID, streamer, suggested title, score, and private preview link.
2. Send via Telegram or email.
3. Record notification status.

### CH-04 — Approval-Gated Publishing
**Trigger:** Clips status changes to APPROVED.

1. Fetch clip, source asset, streamer, and permission evidence.
2. Confirm status = APPROVED.
3. Confirm permission remains ACTIVE and destination is permitted.
4. Confirm required attribution and quality checks.
5. Check Publications for existing idempotency key.
6. If any check fails, set BLOCKED and notify.
7. If all checks pass, send to an official authorized publishing method.
8. Save returned publication URL/status.
9. Create audit event.

**Critical:** Keep this scenario disabled until the entire approval and permission gate has passed tests. Never publish on a mere notification or AI score.

## Error handling
- Add error handlers for provider/API failures.
- Use bounded retries for transient failures.
- Do not retry permission or authorization failures without human action.
- Send sanitized error notifications.
- Do not include API keys or private tokens in messages.

## Scenario naming
Use `CH-01`, `CH-02`, etc. Add version and date to exported blueprint filenames.
