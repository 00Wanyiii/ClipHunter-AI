# CH-04 — Approval-Gated Publishing

**Status:** PLANNED — MUST REMAIN DISABLED UNTIL TESTED.

**Trigger:** Clip status changes to `APPROVED`.

## Mandatory pre-publish checks
- Status is exactly `APPROVED`.
- Reviewer and approval timestamp exist.
- Permission remains active.
- Permission explicitly allows the destination and commercial use if relevant.
- Attribution requirements are satisfied.
- Quality review is passed.
- Clip has no existing successful publication for that destination.
- Publishing account is authorized.

## Failure behavior
If any check fails, set status to `BLOCKED`, record the reason, and notify the operator. Never silently skip a failed check.

## Success behavior
Publish through a supported official method, store returned URL and timestamp, and record an audit event.

## Acceptance tests
- PENDING_REVIEW cannot publish.
- REJECTED cannot publish.
- APPROVED with revoked permission cannot publish.
- APPROVED with active permission can proceed.
- Repeated trigger does not duplicate publication.
