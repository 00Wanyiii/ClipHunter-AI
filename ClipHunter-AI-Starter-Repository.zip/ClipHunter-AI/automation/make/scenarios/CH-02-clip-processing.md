# CH-02 — Candidate Clip Processing

**Status:** PLANNED  
**Trigger:** Source Asset status changes to `VALIDATED`.

## Actions
1. Retrieve source metadata and approved media reference.
2. Submit through a verified, supported clipping provider workflow.
3. Save provider job ID.
4. Receive completion via supported webhook or polling.
5. Validate output timestamps and duration.
6. Save preview/output to restricted storage.
7. Create Clip records with status `PENDING_REVIEW`.
8. Create audit event and send reviewer notification.

## Fallback
If the selected provider does not expose a supported API or Make integration for this operation, use a manual upload step for the MVP. Document the limitation; do not fake an integration.

## Acceptance test
One authorized test recording produces at least one reviewable clip with source attribution and timestamps.
