# CH-01 — Authorized Asset Intake

**Status:** PLANNED  
**Trigger:** New Source Assets record or controlled webhook.

## Filter requirements
- Linked streamer exists.
- Permission Status is `ACTIVE`.
- Permission Checked is true.
- Allowed Operations contains the intended processing action.
- Permission expiry is empty or in the future.
- Asset has a source/file reference.
- Asset ID has not already been processed.

## Actions
1. Retrieve streamer and asset.
2. Apply permission filters.
3. Set asset to `VALIDATED` or `BLOCKED`.
4. Create audit record.
5. Notify operator for blocked assets.

## Acceptance test
A pending-permission source must be blocked. An active, permitted test source must validate. Replaying the same event must not create a second job.
