# Security, Rights, and Permissions

## Permission is a hard prerequisite
A publicly viewable stream is not automatically available for downloading, clipping, commercial reuse, or reposting. Obtain permission from the relevant rights holder and verify platform rules.

For each creator/source, document:
- who granted permission and their authority;
- the source/channel covered;
- whether recording, transcription, editing, clipping, and storage are permitted;
- whether monetization and commercial reuse are permitted;
- permitted platforms and territories;
- required attribution;
- restrictions on music, guests, sponsors, or sensitive content;
- start date, expiry, and revocation process.

If permission is absent, unclear, expired, or revoked, block the workflow.

## Platform and third-party rights
A creator's permission may not cover music, guests, third-party video, game footage, or other embedded works. Flag uncertain material for manual rights review. Follow platform terms and applicable law.

## Editing integrity
- Do not fabricate speech or alter meaning.
- Preserve enough context.
- Avoid misleading titles or captions.
- Do not create defamatory or harassing edits.
- Flag private, sensitive, or potentially harmful content for human review.

## Account security
- Use official OAuth connections wherever possible.
- Store API keys in a secret manager or environment variables.
- Never commit `.env`, tokens, passwords, cookies, or session files.
- Use least-privilege access.
- Rotate exposed credentials immediately.
- Limit Airtable and Drive sharing to required collaborators.

## Retention
Set a retention schedule for raw recordings, working files, rejected clips, and published assets. Delete content when permission ends or retention obligations require it.

## Approval and audit
Every approval must record reviewer, timestamp, clip ID, and intended destination. Recheck permission immediately before publishing. Keep an audit trail of changes and publication outcomes.
