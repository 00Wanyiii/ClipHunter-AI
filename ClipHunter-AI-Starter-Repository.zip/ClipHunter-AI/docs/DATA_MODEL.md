# Data Model and Airtable Setup

Create an Airtable base named **ClipHunter AI** with these tables.

## Table 1 — Streamers

| Field | Type | Notes |
|---|---|---|
| Streamer ID | Single line text | Stable unique ID |
| Name | Single line text | Creator/channel name |
| Platform | Single select | Twitch, YouTube, Kick, Other |
| Channel URL | URL | Public channel reference |
| Permission Status | Single select | PENDING_VERIFICATION, ACTIVE, EXPIRED, REVOKED |
| Permission Evidence | URL / attachment | Agreement or evidence reference |
| Allowed Operations | Multiple select | Process recording, create clips, publish |
| Allowed Destinations | Multiple select | YouTube, TikTok, Instagram, Other |
| Permission Expiry | Date | Optional expiry |
| Restrictions | Long text | Attribution, duration, edits, territory, etc. |
| Notes | Long text | Operator notes |

## Table 2 — Source Assets

| Field | Type | Notes |
|---|---|---|
| Asset ID | Single line text | Unique ID |
| Streamer | Link to Streamers | Required |
| Source Type | Single select | Creator upload, authorized feed, platform-native clip, other approved |
| Source URL / File | URL or attachment | Authorized asset only |
| Permission Checked | Checkbox | Must be true |
| Permission Reference | URL / text | Evidence pointer |
| Duration Seconds | Number | Source duration |
| Status | Single select | RECEIVED, VALIDATED, PROCESSING, COMPLETE, BLOCKED, ERROR |
| Created At | Created time | Audit |

## Table 3 — Clips

| Field | Type | Notes |
|---|---|---|
| Clip ID | Single line text | Unique ID |
| Source Asset | Link to Source Assets | Required |
| Streamer | Link to Streamers | Lookup or linked |
| Start Seconds | Number | In-point |
| End Seconds | Number | Out-point |
| Duration Seconds | Formula/number | Normally 15–60 |
| Preview File | Attachment / URL | Stored preview |
| Title | Single line text | Suggested title |
| Caption Text | Long text | Transcript/subtitles |
| Hook | Long text | Optional opening |
| AI Score | Number | 1–100, editorial estimate |
| Status | Single select | PENDING_REVIEW, APPROVED, REJECTED, NEEDS_EDIT, BLOCKED, PUBLISHED |
| Reviewer | Collaborator/text | Human reviewer |
| Review Notes | Long text | Decision notes |
| Permission Checked At | Date/time | Recheck before publishing |

## Table 4 — Publications

| Field | Type | Notes |
|---|---|---|
| Publication ID | Single line text | Unique ID |
| Clip | Link to Clips | Required |
| Destination | Single select | YouTube, TikTok, Instagram, Other |
| Status | Single select | QUEUED, PUBLISHED, FAILED, BLOCKED |
| Published URL | URL | Result |
| Published At | Date/time | Result |
| Idempotency Key | Single line text | Prevent duplicate posts |

## Table 5 — Audit Log

| Field | Type | Notes |
|---|---|---|
| Event ID | Single line text | Unique ID |
| Entity Type | Single select | Streamer, Asset, Clip, Publication |
| Entity ID | Single line text | Related ID |
| Event | Single line text | e.g. APPROVED |
| Actor | Single line text | User or automation |
| Timestamp | Date/time | Event time |
| Details | Long text | Sanitized details |

## State rules
- New clip: `PENDING_REVIEW`.
- `APPROVED` requires an authenticated human reviewer.
- `REJECTED` cannot publish.
- `NEEDS_EDIT` returns to editing and then back to `PENDING_REVIEW`.
- `BLOCKED` requires a human to resolve the underlying issue.
- `PUBLISHED` requires a successful destination response and publication record.
