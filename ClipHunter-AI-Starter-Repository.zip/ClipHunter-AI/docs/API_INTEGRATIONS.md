# API and Service Integrations

This document describes integration boundaries. It does not assert that every provider offers the required API on every plan.

## Make.com
Use Make for orchestration, webhooks, filters, routers, retries, and notifications. Check current module availability and plan limits. Prefer official OAuth connections.

## Airtable
Use Airtable as the initial operational database and review queue. Protect personal access tokens. Avoid exposing base data publicly.

## Google Drive
Use a dedicated folder with restricted access. Avoid public links unless specifically required and safe. Apply a retention policy to source recordings and rendered clips.

## OpusClip or alternative clipping service
Before selecting a provider, verify:
- accepted input types and maximum duration/size;
- whether input can be supplied through an official integration/API or must be uploaded manually;
- whether real-time/live input is supported;
- output format, caption editing, and timestamp metadata;
- commercial usage rights and plan limits;
- data retention and privacy terms;
- whether the provider's terms permit the intended creator content.

If no supported API exists, begin with a manual upload/download proof of concept rather than inventing an endpoint or automating browser actions that violate terms.

## Telegram
Use a bot only for notifications and simple review links. Never send private media to an unintended chat. Protect bot token and chat ID.

## Platform-specific source access
Use official platform APIs and creator-authorized workflows. Check current developer terms, permissions/scopes, rate limits, and content rules. Do not scrape, bypass access controls, or assume that public availability permits reuse.

## Optional custom code
Use a small adapter only after a provider is selected and official API documentation is verified. Define:
- input contract;
- output contract;
- authentication;
- retry and rate-limit behavior;
- error mapping;
- data retention;
- tests with sample fixtures.

Do not store secrets in Git.
