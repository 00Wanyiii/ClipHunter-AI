# Deployment and Beginner Setup Guide

This is the initial setup sequence. Complete one stage at a time. Do not share passwords or secret keys in chat.

## Stage A — GitHub repository

1. Sign in at https://github.com/.
2. Select **New repository**.
3. Name it `ClipHunter-AI`.
4. Set visibility to **Private**.
5. Do not initialize with extra files if you are uploading this package as-is.
6. Upload the extracted folder contents, or use GitHub Desktop.
7. Confirm `README.md` and `MASTER_PROMPT.md` appear at the repository root.

## Stage B — Airtable

1. Create an account at https://airtable.com/.
2. Create a base named `ClipHunter AI`.
3. Create five tables: `Streamers`, `Source Assets`, `Clips`, `Publications`, `Audit Log`.
4. Use `docs/DATA_MODEL.md` to create the fields.
5. Keep the base private.
6. Do not add famous creators as active sources unless permission has been obtained. They may be listed as `PENDING_VERIFICATION` research targets only.

## Stage C — Google Drive

1. Create a folder named `ClipHunter AI`.
2. Create subfolders: `Source Recordings`, `Candidate Clips`, `Approved Clips`, `Published Assets`, `Test Assets`.
3. Restrict access to your account and trusted collaborators.
4. Upload only authorized test footage.

## Stage D — Telegram notifications (optional)

1. Install Telegram.
2. Create a bot using Telegram's official BotFather flow.
3. Keep the bot token private.
4. Add the bot to the intended private chat or group.
5. Test a notification only after connecting it through Make.

## Stage E — Make.com

1. Create an account at https://www.make.com/.
2. Create a folder named `ClipHunter AI`.
3. Create scenarios following `automation/make/README.md`.
4. Connect Airtable, Drive, and Telegram using official connection flows.
5. Do not enable publishing in the first scenario.

## Stage F — Clipping provider

1. Review the provider's current plan, terms, and accepted inputs.
2. Start with a short authorized sample recording.
3. Generate clips manually first.
4. Check captions, context, source timestamps, and output quality.
5. Only automate the provider step if an official supported integration/API is available and suitable.

## Stage G — Secrets and local code

If a custom code adapter is later needed:
1. Copy `.env.example` to `.env`.
2. Populate secrets locally only.
3. Ensure `.env` is ignored by Git.
4. Never paste secret values into issues, chat, or documentation.
5. Use a secret manager for deployed services.

## First practical test
Use a 5–15 minute recording you own or have explicit permission to process. Create at least three candidate clips, review them, and record test results. Do not publish until all rights and approval checks pass.
