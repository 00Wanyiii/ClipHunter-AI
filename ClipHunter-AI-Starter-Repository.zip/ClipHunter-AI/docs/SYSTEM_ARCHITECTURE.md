# System Architecture

## Logical flow

```mermaid
flowchart TD
    A[Creator-authorized source] --> B[Source registry and permission check]
    B -->|Active permission| C[Media intake]
    B -->|Missing or invalid permission| X[Stop and flag]
    C --> D[AI highlight detection]
    D --> E[Clip generation and editing]
    E --> F[Storage]
    F --> G[Airtable review queue]
    G -->|Reject| H[Rejected / archived]
    G -->|Request edit| E
    G -->|Approve| I[Final rights and quality gate]
    I -->|Pass| J[Authorized publishing]
    I -->|Fail| X
    J --> K[Audit log and analytics]
```

## Layers

### 1. Source and permission layer
Stores streamer, channel, source asset, permission evidence, allowed operations, expiry, and destinations. A source cannot enter processing unless permission is active and covers the intended action.

### 2. Intake layer
Receives creator-provided files, licensed feeds, platform-authorized exports, or another explicitly permitted source. Do not infer download rights from a public URL.

### 3. Intelligence layer
Uses transcription, scene/audio cues, and editorial prompts to propose candidate moments. Scores are prioritization hints, not predictions.

### 4. Editing layer
Creates a clip using a provider with a supported and permitted input path. Retain original timestamps and source attribution.

### 5. Review layer
Airtable or equivalent stores candidates and decisions. Human review is mandatory.

### 6. Publishing layer
Only approved clips pass through a second independent permission and quality check. Use official publishing APIs or approved platform workflows.

## Suggested no-code topology
- Make scenario A: authorized asset intake.
- Make scenario B: candidate processing and clip generation.
- Make scenario C: review notification.
- Make scenario D: approval-triggered publishing.
- Airtable: source registry, assets, clips, audit log.
- Drive: media files and previews.
- Telegram: review alerts.

## Reliability
- Use unique IDs for source assets and clips.
- Store provider job IDs.
- Add retry limits and error routes.
- Avoid processing the same asset/version twice.
- Use a publication idempotency key (clip ID + destination).
- Keep publishing disabled until end-to-end tests pass.
