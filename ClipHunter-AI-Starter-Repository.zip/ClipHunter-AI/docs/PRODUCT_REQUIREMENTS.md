# Product Requirements

## Problem
Clipping operators spend substantial time watching long livestreams, finding moments, editing them, captioning them, and preparing platform-specific posts.

## Proposed solution
ClipHunter AI processes creator-authorized recordings or feeds, proposes short-form highlights, and routes them through a human review queue.

## Primary user
The founder/operator, initially working alone and preferring no-code tools with step-by-step guidance.

## User stories
- As an operator, I can register a streamer and record the permission scope.
- As an operator, I can register an authorized recording.
- As an operator, I can receive candidate highlights with timestamps and previews.
- As an operator, I can see why the AI selected a moment.
- As an operator, I can approve, reject, or request an edit.
- As an operator, I can publish only approved clips to an authorized destination.
- As an operator, I can trace a published clip back to its source and permission record.
- As an operator, I can see processing failures and estimated costs.

## Functional requirements
1. Streamer/source registry with permission state and permitted uses.
2. Media intake with source URL, asset ID, duration, and rights reference.
3. Highlight candidate generation with in/out timestamps.
4. Clip generation or editing through a supported provider.
5. Captions, title, description, and platform aspect ratio metadata.
6. Review queue and explicit approval action.
7. Publishing gate with rights, approval, quality, and duplicate checks.
8. Audit log and error handling.
9. Cost and usage tracking.

## Non-functional requirements
- Beginner-friendly operations.
- Low initial recurring cost.
- Secure handling of credentials and media.
- Retry-safe automation.
- Clear auditability.
- No unsupported scraping or circumvention.
- Data minimization and retention limits.

## MVP scope
The MVP uses one authorized sample recording, one clipping provider, Airtable review, and manual publishing. Live ingestion and multi-platform publishing are later milestones.

## Out of scope for MVP
- Arbitrary public-stream scraping.
- Automatic publishing without review.
- Custom model training.
- Guaranteed virality or income.
