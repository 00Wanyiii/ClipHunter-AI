# Test Plan

Use only footage owned by the project operator or explicitly authorized for the test.

## Test cases

| ID | Test | Expected result |
|---|---|---|
| T01 | Register source with active permission | Source can be validated |
| T02 | Register source with pending permission | Processing is blocked |
| T03 | Permission has expired | Processing/publishing is blocked |
| T04 | Ingest duplicate asset | Duplicate is detected; no duplicate job |
| T05 | Submit valid sample recording | Processing job is created |
| T06 | Candidate timestamps outside source duration | Candidate is rejected or flagged |
| T07 | Generate clip | Output and metadata are stored |
| T08 | New clip enters review | Status is PENDING_REVIEW |
| T09 | Reject clip | Publishing remains blocked |
| T10 | Approve clip | Clip becomes eligible for final gate |
| T11 | Revoke permission after approval | Publishing is blocked |
| T12 | Attempt duplicate publication | Duplicate is prevented |
| T13 | Provider failure | Error is logged and operator notified |
| T14 | Missing attribution | Quality gate blocks or flags clip |

## MVP acceptance criteria
- At least one authorized recording is processed.
- At least three candidate clips are created or a provider limitation is documented.
- All clips have source reference and timestamps.
- Human review is required.
- Rejected/unreviewed clips cannot publish.
- Permission is rechecked before publication.
- The test results and actual costs are recorded.

## Test report template
- Date:
- Test operator:
- Source permission reference:
- Asset ID:
- Tests run:
- Pass/fail:
- Provider and plan:
- Actual cost:
- Errors:
- Follow-up actions:
