# Workflow Specifications

## WF-01 — Register streamer and permission
**Trigger:** operator adds a creator/channel.

1. Create streamer record.
2. Record platform and channel URL.
3. Record permission status, evidence reference, permitted processing, permitted destinations, expiry, and restrictions.
4. Set status to `ACTIVE` only after evidence is checked.
5. If unclear, set `PENDING_VERIFICATION`; processing is blocked.

**Output:** streamer record and audit event.

## WF-02 — Authorized media intake
**Trigger:** new media asset is added by an authorized operator or approved connector.

1. Validate source streamer exists.
2. Confirm permission status is active and covers recording/processing.
3. Confirm asset is not already registered.
4. Store source URL/file ID, duration, upload time, and checksum if available.
5. Create processing job.

**Failure:** stop and notify if permission is missing, expired, or insufficient.

## WF-03 — Highlight detection and clip creation
**Trigger:** validated asset enters processing.

1. Submit asset through the provider's supported interface.
2. Request candidate highlights with start/end timestamps.
3. Validate timestamps against source duration.
4. Create edited clips with accurate captions.
5. Store output file and metadata.
6. Set clip status to `PENDING_REVIEW`.

## WF-04 — Human review
**Trigger:** clip enters review queue.

Reviewer can:
- Approve.
- Reject.
- Request edit with notes.

Every action records reviewer, timestamp, and notes. Approval does not bypass the final rights/quality gate.

## WF-05 — Publish approved clip
**Trigger:** clip status changes to `APPROVED`.

Before publishing, independently verify:
- permission is still active;
- destination is permitted;
- clip status is approved;
- quality checks pass;
- no prior publication exists;
- publishing account is authorized.

If any check fails, set `BLOCKED` and notify. Otherwise publish using a supported official method and record result.

## WF-06 — Error handling
- Retry transient failures with bounded retries.
- Do not retry permission failures automatically.
- Do not duplicate media jobs or posts.
- Store sanitized error details.
- Notify operator with a clear action.
