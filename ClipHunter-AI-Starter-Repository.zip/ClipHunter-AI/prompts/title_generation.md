# Title and Hook Generation Prompt

Generate:
- 3 concise title options;
- 2 opening hook options;
- a neutral one-sentence description;
- source attribution text.

Rules:
- Be engaging without misleading viewers.
- Do not claim a reaction or statement that is absent from the clip.
- Do not invent facts, identities, or context.
- Avoid defamatory, hateful, harassing, or privacy-invasive framing.
- Do not use "you won't believe" or similar clickbait unless the clip genuinely supports the framing.
- Preserve creator attribution and any required credit.
