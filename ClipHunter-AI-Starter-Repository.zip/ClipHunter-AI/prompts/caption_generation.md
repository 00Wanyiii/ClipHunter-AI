# Caption Generation Prompt

Create accurate subtitles from the supplied authorized clip.

Rules:
- Preserve the speaker's actual words.
- Do not invent or silently rewrite speech.
- Use punctuation and readable line breaks.
- Mark uncertain words rather than guessing.
- Do not remove qualifiers that change meaning.
- Avoid captions that cover faces or important on-screen information.
- If speakers overlap, distinguish speakers only when reliably identifiable.
- Return timestamped caption segments when supported by the tool.
- Flag sensitive personal information for human review.
