# Clip Scoring Prompt

Score each candidate from 1–100 as an editorial prioritization aid, not a prediction of reach.

Suggested dimensions:
- Immediate clarity and hook: 0–20
- Emotional or entertainment value: 0–20
- Self-contained context: 0–20
- Distinctiveness: 0–15
- Audio/visual clarity: 0–15
- Short-form suitability: 0–10

Subtract or flag for:
- missing context;
- inaudible speech;
- misleading edit risk;
- rights uncertainty;
- privacy/safety concern;
- excessive dead air.

Return:
- total_score;
- dimension_scores;
- rationale;
- quality_flags;
- human_review_priority.

A high score never overrides permission, safety, or human approval requirements.
