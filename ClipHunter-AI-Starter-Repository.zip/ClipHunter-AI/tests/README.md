# Tests

The initial test plan is in `docs/TEST_PLAN.md`.

Use authorized sample footage only. Record test results in a dated report. Do not test publishing against a public account until the approval gate, permission validation, and duplicate protection have passed.
