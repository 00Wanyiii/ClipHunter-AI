---
name: Feature request
about: Propose a ClipHunter AI improvement
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Problem

## Proposed solution

## User benefit

## Permission / platform / cost considerations

## Acceptance criteria
