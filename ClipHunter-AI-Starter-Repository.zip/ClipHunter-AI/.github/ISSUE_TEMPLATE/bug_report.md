---
name: Bug report
about: Report a reproducible ClipHunter AI issue
title: "[BUG] "
labels: bug
assignees: ''
---

## Summary

## Steps to reproduce

## Expected result

## Actual result

## Workflow / provider

## Relevant sanitized logs

Do not include passwords, tokens, private media links, or personal data.
