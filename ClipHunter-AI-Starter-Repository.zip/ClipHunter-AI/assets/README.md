# Assets

Store non-secret project assets here, such as:
- brand logo and approved templates;
- test screenshots that contain no private data;
- sample caption styles;
- documentation diagrams.

Do not store API keys, credentials, private creator recordings, or copyrighted source media unless storage is authorized and appropriately access-controlled. Large media should normally live in restricted storage, not Git.
